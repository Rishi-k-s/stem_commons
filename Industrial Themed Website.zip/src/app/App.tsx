import { useState } from "react";
import { Search, MapPin, ExternalLink, Filter, X, ArrowLeft, ChevronRight } from "lucide-react";

/* ─── DATA ─────────────────────────────────────────────────── */

const resources = [
  { id: 1, name: "FabLab IIT Delhi",               type: "Makerspace", city: "New Delhi",  state: "Delhi",        status: "Working",            facilities: ["3D Printing","Laser Cutting","CNC Machines","Electronics Lab"], contact: "fablab@iitd.ac.in" },
  { id: 2, name: "ATAL Tinkering Lab — KV No. 1",  type: "ATAL Lab",   city: "Mumbai",      state: "Maharashtra",  status: "Working",            facilities: ["Robotics","Electronics Lab","3D Printing"],                    contact: "atl.kv1mum@gov.in" },
  { id: 3, name: "Tinkerers' Paradise",             type: "Makerspace", city: "Bangalore",   state: "Karnataka",    status: "Working",            facilities: ["3D Printing","Robotics","Laser Cutting"],                     contact: "hello@tinkerers.in" },
  { id: 4, name: "STEM Ventures India",             type: "Vendor",     city: "Pune",        state: "Maharashtra",  status: "Working",            facilities: ["Electronics Lab","Robotics"],                                  contact: "info@stemventures.in" },
  { id: 5, name: "ATAL Innovation Centre Chennai",  type: "ATAL Lab",   city: "Chennai",     state: "Tamil Nadu",   status: "Working",            facilities: ["CNC Machines","Electronics Lab","3D Printing"],               contact: "atl.chennai@gov.in" },
  { id: 6, name: "Maker's Collective Hyderabad",    type: "Makerspace", city: "Hyderabad",   state: "Telangana",    status: "Planned",            facilities: ["3D Printing","Laser Cutting"],                                 contact: "makers@collective.hyd.in" },
  { id: 7, name: "BotBridge Robotics Supply",       type: "Vendor",     city: "Ahmedabad",   state: "Gujarat",      status: "Working",            facilities: ["Robotics","Electronics Lab"],                                  contact: "supply@botbridge.in" },
  { id: 8, name: "ATL Vidya Mandir School",         type: "ATAL Lab",   city: "Jaipur",      state: "Rajasthan",    status: "Temporarily Closed", facilities: ["Robotics","Electronics Lab"],                                  contact: "atl.jaipur@gov.in" },
  { id: 9, name: "FutureLab Kolkata",               type: "Makerspace", city: "Kolkata",     state: "West Bengal",  status: "Working",            facilities: ["3D Printing","CNC Machines","Electronics Lab"],               contact: "lab@futurelab.kol.in" },
];

const statusStyles: Record<string, { color: string; bg: string; border: string }> = {
  "Working":            { color: "#166534", bg: "rgba(22,101,52,0.07)",  border: "rgba(22,101,52,0.2)"  },
  "Planned":            { color: "#92400e", bg: "rgba(146,64,14,0.07)",  border: "rgba(146,64,14,0.2)"  },
  "Temporarily Closed": { color: "#9a3412", bg: "rgba(154,52,18,0.07)",  border: "rgba(154,52,18,0.2)"  },
  "Permanently Closed": { color: "#7f1d1d", bg: "rgba(127,29,29,0.07)",  border: "rgba(127,29,29,0.2)"  },
};

const typeColors: Record<string, string> = {
  "Makerspace": "#c41a0a",
  "ATAL Lab":   "#b06010",
  "Vendor":     "#1d6fa8",
};

const allFacilities = ["3D Printing", "Laser Cutting", "CNC Machines", "Robotics", "Electronics Lab"];
const allStatuses   = ["Working", "Planned", "Temporarily Closed", "Permanently Closed"];
const allTypes      = ["Makerspace", "ATAL Lab", "Vendor"];

const RED = "#c41a0a";

/* ─── SHARED CHROME ─────────────────────────────────────────── */

const gridBg = {
  pointerEvents: "none" as const,
  position: "fixed" as const,
  inset: 0,
  zIndex: 0,
  backgroundImage:
    "linear-gradient(rgba(196,26,10,0.035) 1px, transparent 1px), linear-gradient(90deg, rgba(196,26,10,0.035) 1px, transparent 1px)",
  backgroundSize: "48px 48px",
};

/* ─── APP ───────────────────────────────────────────────────── */

export default function App() {
  const [page, setPage]   = useState<"landing" | "resources">("landing");
  const [query, setQuery] = useState("");

  function goToResources(q = query) {
    setQuery(q);
    setPage("resources");
  }

  return page === "landing"
    ? <LandingPage query={query} setQuery={setQuery} goToResources={goToResources} />
    : <ResourcesPage query={query} setQuery={setQuery} goBack={() => setPage("landing")} goToResources={goToResources} />;
}

/* ─── LANDING PAGE ───────────────────────────────────────────── */

function LandingPage({
  query,
  setQuery,
  goToResources,
}: {
  query: string;
  setQuery: (v: string) => void;
  goToResources: (q?: string) => void;
}) {
  const stats = [
    { value: "250+",   label: "MAKERSPACES" },
    { value: "1,200+", label: "ATAL LABS"   },
    { value: "85+",    label: "VENDORS"     },
    { value: "28",     label: "STATES"      },
  ];

  return (
    <div
      style={{
        height: "100vh",
        overflow: "hidden",
        display: "flex",
        flexDirection: "column",
        background: "#f5f2ee",
        color: "#1a1a1a",
        fontFamily: "'Barlow', 'Arial Narrow', sans-serif",
        position: "relative",
      }}
    >
      <div style={gridBg} />

      {/* Top rule */}
      <div style={{ height: "3px", background: RED, flexShrink: 0, position: "relative", zIndex: 10 }} />

      {/* Header */}
      <header
        style={{
          flexShrink: 0,
          borderBottom: "1px solid rgba(0,0,0,0.08)",
          background: "#f5f2ee",
          position: "relative",
          zIndex: 10,
        }}
      >
        <div
          style={{
            maxWidth: "1280px",
            margin: "0 auto",
            padding: "0 32px",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            height: "56px",
          }}
        >
          <div>
            <div style={{ fontFamily: "'Oswald', sans-serif", fontSize: "1.4rem", fontWeight: 700, letterSpacing: "0.06em", color: "#1a1a1a", lineHeight: 1 }}>
              STEM COMMONS
            </div>
            <div style={{ fontFamily: "monospace", fontSize: "0.55rem", letterSpacing: "0.3em", color: RED, marginTop: "1px" }}>
              DISCOVERY PLATFORM
            </div>
          </div>
          <div style={{ fontFamily: "monospace", fontSize: "0.6rem", color: "rgba(0,0,0,0.28)", letterSpacing: "0.2em" }}>v1.0</div>
          <nav style={{ display: "flex", alignItems: "center", gap: "28px" }}>
            {["About", "Contact"].map((item) => (
              <button key={item} style={navBtnStyle}
                onMouseEnter={(e) => (e.currentTarget.style.color = "#1a1a1a")}
                onMouseLeave={(e) => (e.currentTarget.style.color = "rgba(0,0,0,0.45)")}
              >
                {item.toUpperCase()}
              </button>
            ))}
            <button
              style={{ fontFamily: "'Oswald', sans-serif", fontSize: "0.78rem", letterSpacing: "0.15em", color: RED, background: "none", border: `1px solid ${RED}`, cursor: "pointer", padding: "5px 14px", transition: "background 0.15s" }}
              onMouseEnter={(e) => (e.currentTarget.style.background = "rgba(196,26,10,0.08)")}
              onMouseLeave={(e) => (e.currentTarget.style.background = "none")}
            >
              SUBMIT
            </button>
          </nav>
        </div>
      </header>

      {/* Hero — takes remaining space */}
      <main
        style={{
          flex: 1,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          padding: "0 24px",
          position: "relative",
          zIndex: 10,
          gap: "0",
        }}
      >
        {/* Badge */}
        <div
          style={{
            border: `1px solid ${RED}`,
            padding: "3px 14px",
            fontFamily: "monospace",
            fontSize: "0.6rem",
            letterSpacing: "0.3em",
            color: RED,
            marginBottom: "28px",
          }}
        >
          CONNECT · DISCOVER · INNOVATE
        </div>

        {/* Headline */}
        <h1 style={{ fontFamily: "'Oswald', sans-serif", fontSize: "clamp(2.4rem, 5.5vw, 4rem)", fontWeight: 700, lineHeight: 1.0, letterSpacing: "0.03em", color: "#1a1a1a", margin: 0 }}>
          FIND YOUR
        </h1>
        <h1 style={{ fontFamily: "'Oswald', sans-serif", fontSize: "clamp(2.4rem, 5.5vw, 4rem)", fontWeight: 700, lineHeight: 1.05, letterSpacing: "0.03em", color: RED, margin: "0 0 12px" }}>
          NEXT STEM SPACE
        </h1>
        <p style={{ color: "rgba(0,0,0,0.48)", fontSize: "0.95rem", lineHeight: 1.6, maxWidth: "420px", textAlign: "center", margin: "0 0 36px" }}>
          Connect with Makerspaces, ATAL Tinkering Labs, and STEM vendors across India.
        </p>

        {/* Search box */}
        <div style={{ width: "100%", maxWidth: "560px", marginBottom: "16px" }}>
          <div style={{ background: RED, fontFamily: "monospace", fontSize: "0.56rem", letterSpacing: "0.3em", color: "#fff", padding: "3px 12px", textAlign: "left" }}>
            SEARCH RESOURCES
          </div>
          <div style={{ display: "flex", border: `1px solid ${RED}`, background: "#fff" }}>
            <input
              type="text"
              placeholder="Search by name, city, or location..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && goToResources()}
              style={{ flex: 1, background: "transparent", border: "none", outline: "none", padding: "13px 16px", color: "#1a1a1a", fontFamily: "'Barlow', sans-serif", fontSize: "0.95rem" }}
            />
            <button
              onClick={() => goToResources()}
              style={{ background: RED, border: "none", padding: "13px 22px", color: "#fff", fontFamily: "'Oswald', sans-serif", fontSize: "0.82rem", letterSpacing: "0.1em", cursor: "pointer", display: "flex", alignItems: "center", gap: "7px", transition: "opacity 0.15s" }}
              onMouseEnter={(e) => (e.currentTarget.style.opacity = "0.82")}
              onMouseLeave={(e) => (e.currentTarget.style.opacity = "1")}
            >
              <Search size={14} /> SEARCH
            </button>
          </div>
        </div>

        {/* Browse button */}
        <button
          onClick={() => goToResources("")}
          style={{
            display: "flex",
            alignItems: "center",
            gap: "7px",
            background: "transparent",
            border: "1px solid rgba(0,0,0,0.18)",
            padding: "9px 22px",
            color: "rgba(0,0,0,0.5)",
            fontFamily: "'Oswald', sans-serif",
            fontSize: "0.76rem",
            letterSpacing: "0.18em",
            cursor: "pointer",
            transition: "border-color 0.15s, color 0.15s",
            marginBottom: "48px",
          }}
          onMouseEnter={(e) => { e.currentTarget.style.borderColor = RED; e.currentTarget.style.color = RED; }}
          onMouseLeave={(e) => { e.currentTarget.style.borderColor = "rgba(0,0,0,0.18)"; e.currentTarget.style.color = "rgba(0,0,0,0.5)"; }}
        >
          BROWSE ALL RESOURCES <ChevronRight size={13} />
        </button>

        {/* Stats */}
        <div
          style={{
            display: "flex",
            gap: "0",
            border: "1px solid rgba(0,0,0,0.1)",
            background: "#ede9e3",
          }}
        >
          {stats.map((s, i) => (
            <div
              key={s.label}
              style={{
                padding: "14px 32px",
                borderRight: i < stats.length - 1 ? "1px solid rgba(0,0,0,0.1)" : "none",
                textAlign: "center",
              }}
            >
              <div style={{ fontFamily: "'Oswald', sans-serif", fontSize: "1.4rem", fontWeight: 700, color: "#1a1a1a", lineHeight: 1 }}>
                {s.value}
              </div>
              <div style={{ fontFamily: "monospace", fontSize: "0.52rem", letterSpacing: "0.22em", color: "rgba(0,0,0,0.38)", marginTop: "3px" }}>
                {s.label}
              </div>
            </div>
          ))}
        </div>
      </main>

      {/* Footer */}
      <footer
        style={{
          flexShrink: 0,
          borderTop: "1px solid rgba(0,0,0,0.08)",
          background: "#ede9e3",
          position: "relative",
          zIndex: 10,
        }}
      >
        <div style={{ height: "2px", background: RED }} />
        <div
          style={{
            maxWidth: "1280px",
            margin: "0 auto",
            padding: "8px 32px",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <span style={{ fontFamily: "monospace", fontSize: "0.58rem", letterSpacing: "0.14em", color: "rgba(0,0,0,0.35)" }}>
            © 2026 STEM COMMONS. ALL RIGHTS RESERVED.
          </span>
          <div style={{ display: "flex", gap: "24px" }}>
            {["ABOUT", "CONTACT", "PRIVACY"].map((link) => (
              <button
                key={link}
                style={{ fontFamily: "monospace", fontSize: "0.58rem", letterSpacing: "0.14em", color: "rgba(0,0,0,0.35)", background: "none", border: "none", cursor: "pointer", transition: "color 0.15s", padding: 0 }}
                onMouseEnter={(e) => (e.currentTarget.style.color = RED)}
                onMouseLeave={(e) => (e.currentTarget.style.color = "rgba(0,0,0,0.35)")}
              >
                {link}
              </button>
            ))}
          </div>
        </div>
      </footer>
    </div>
  );
}

/* ─── RESOURCES PAGE ─────────────────────────────────────────── */

function ResourcesPage({
  query,
  setQuery,
  goBack,
  goToResources,
}: {
  query: string;
  setQuery: (v: string) => void;
  goBack: () => void;
  goToResources: (q?: string) => void;
}) {
  const [selectedTypes,      setSelectedTypes]      = useState<string[]>([]);
  const [selectedStatuses,   setSelectedStatuses]   = useState<string[]>([]);
  const [selectedFacilities, setSelectedFacilities] = useState<string[]>([]);
  const [showAll,            setShowAll]            = useState(false);

  function toggle<T>(arr: T[], set: (v: T[]) => void, val: T) {
    set(arr.includes(val) ? arr.filter((x) => x !== val) : [...arr, val]);
  }

  const filtered = resources.filter((r) => {
    const q = query.toLowerCase();
    return (
      (!q || r.name.toLowerCase().includes(q) || r.city.toLowerCase().includes(q) || r.state.toLowerCase().includes(q)) &&
      (!selectedTypes.length      || selectedTypes.includes(r.type))      &&
      (!selectedStatuses.length   || selectedStatuses.includes(r.status)) &&
      (!selectedFacilities.length || selectedFacilities.every((f) => r.facilities.includes(f)))
    );
  });

  const displayed = showAll ? filtered : filtered.slice(0, 9);
  const hasFilters = selectedTypes.length || selectedStatuses.length || selectedFacilities.length;

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#f5f2ee",
        color: "#1a1a1a",
        fontFamily: "'Barlow', 'Arial Narrow', sans-serif",
        position: "relative",
      }}
    >
      <div style={gridBg} />

      <div style={{ height: "3px", background: RED, position: "relative", zIndex: 10 }} />

      {/* Header */}
      <header style={{ borderBottom: "1px solid rgba(0,0,0,0.08)", background: "#f5f2ee", position: "sticky", top: 0, zIndex: 20 }}>
        <div
          style={{
            maxWidth: "1280px",
            margin: "0 auto",
            padding: "0 32px",
            display: "flex",
            alignItems: "center",
            gap: "24px",
            height: "56px",
          }}
        >
          {/* Back */}
          <button
            onClick={goBack}
            style={{ display: "flex", alignItems: "center", gap: "6px", background: "none", border: "none", cursor: "pointer", color: "rgba(0,0,0,0.45)", fontFamily: "'Oswald', sans-serif", fontSize: "0.75rem", letterSpacing: "0.12em", flexShrink: 0, transition: "color 0.15s", padding: 0 }}
            onMouseEnter={(e) => (e.currentTarget.style.color = RED)}
            onMouseLeave={(e) => (e.currentTarget.style.color = "rgba(0,0,0,0.45)")}
          >
            <ArrowLeft size={14} /> HOME
          </button>

          <div style={{ width: "1px", height: "24px", background: "rgba(0,0,0,0.12)" }} />

          {/* Logo */}
          <div
            style={{ fontFamily: "'Oswald', sans-serif", fontSize: "1.1rem", fontWeight: 700, letterSpacing: "0.06em", color: "#1a1a1a", cursor: "pointer", flexShrink: 0 }}
            onClick={goBack}
          >
            STEM COMMONS
          </div>

          {/* Inline search */}
          <div style={{ flex: 1, display: "flex", maxWidth: "520px" }}>
            <div style={{ display: "flex", border: `1px solid rgba(0,0,0,0.15)`, background: "#fff", width: "100%", transition: "border-color 0.15s" }}
              onFocus={(e) => (e.currentTarget.style.borderColor = RED)}
              onBlur={(e) => (e.currentTarget.style.borderColor = "rgba(0,0,0,0.15)")}
            >
              <input
                type="text"
                placeholder="Search resources..."
                value={query}
                onChange={(e) => { setQuery(e.target.value); setShowAll(false); }}
                onKeyDown={(e) => e.key === "Enter" && goToResources(query)}
                style={{ flex: 1, background: "transparent", border: "none", outline: "none", padding: "8px 14px", color: "#1a1a1a", fontFamily: "'Barlow', sans-serif", fontSize: "0.88rem" }}
              />
              <button
                onClick={() => goToResources(query)}
                style={{ background: "none", border: "none", padding: "0 12px", color: "rgba(0,0,0,0.35)", cursor: "pointer" }}
              >
                <Search size={14} />
              </button>
            </div>
          </div>

          <div style={{ marginLeft: "auto", fontFamily: "monospace", fontSize: "0.62rem", color: "rgba(0,0,0,0.3)", letterSpacing: "0.15em", whiteSpace: "nowrap" }}>
            <span style={{ color: RED }}>{filtered.length}</span> RESULTS
          </div>
        </div>
      </header>

      {/* Main */}
      <main
        style={{
          maxWidth: "1280px",
          margin: "0 auto",
          padding: "32px 32px 64px",
          position: "relative",
          zIndex: 10,
          display: "flex",
          gap: "32px",
          alignItems: "flex-start",
        }}
      >
        {/* Sidebar */}
        <aside style={{ width: "200px", flexShrink: 0, position: "sticky", top: "72px" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "18px" }}>
            <span style={{ fontFamily: "monospace", fontSize: "0.58rem", letterSpacing: "0.22em", color: "rgba(0,0,0,0.32)" }}>
              — FILTERS
            </span>
            {hasFilters ? (
              <button
                onClick={() => { setSelectedTypes([]); setSelectedStatuses([]); setSelectedFacilities([]); }}
                style={{ fontFamily: "monospace", fontSize: "0.56rem", color: RED, background: "none", border: "none", cursor: "pointer", letterSpacing: "0.1em", display: "flex", alignItems: "center", gap: "3px" }}
              >
                <X size={9} /> CLEAR
              </button>
            ) : null}
          </div>

          <SidebarSection title="RESOURCE TYPE"  items={allTypes}      selected={selectedTypes}      onToggle={(v) => { toggle(selectedTypes, setSelectedTypes, v); setShowAll(false); }} />
          <SidebarSection title="STATUS"         items={allStatuses}   selected={selectedStatuses}   onToggle={(v) => { toggle(selectedStatuses, setSelectedStatuses, v); setShowAll(false); }} />
          <SidebarSection title="TOP FACILITIES" items={allFacilities} selected={selectedFacilities} onToggle={(v) => { toggle(selectedFacilities, setSelectedFacilities, v); setShowAll(false); }} checkbox />

          <div style={{ marginTop: "24px" }}>
            <ActionBtn filled>SUBMIT A RESOURCE</ActionBtn>
          </div>
        </aside>

        {/* Grid */}
        <div style={{ flex: 1, minWidth: 0 }}>
          {/* Sort bar */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              borderBottom: "1px solid rgba(0,0,0,0.08)",
              paddingBottom: "12px",
              marginBottom: "20px",
            }}
          >
            <span style={{ fontFamily: "monospace", fontSize: "0.65rem", letterSpacing: "0.12em", color: "rgba(0,0,0,0.4)" }}>
              {query ? `RESULTS FOR "${query.toUpperCase()}"` : "ALL RESOURCES"}
            </span>
            <div style={{ display: "flex", alignItems: "center", gap: "6px", color: "rgba(0,0,0,0.3)" }}>
              <Filter size={10} />
              <span style={{ fontFamily: "monospace", fontSize: "0.6rem", letterSpacing: "0.1em" }}>SORT: RELEVANCE</span>
            </div>
          </div>

          {filtered.length === 0 ? (
            <div style={{ textAlign: "center", padding: "80px 0", fontFamily: "monospace", fontSize: "0.72rem", letterSpacing: "0.2em", color: "rgba(0,0,0,0.28)" }}>
              NO RESOURCES MATCH YOUR FILTERS
            </div>
          ) : (
            <>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))", gap: "14px" }}>
                {displayed.map((r) => <ResourceCard key={r.id} resource={r} />)}
              </div>

              {filtered.length > 9 && (
                <div style={{ textAlign: "center", marginTop: "32px" }}>
                  <button
                    onClick={() => setShowAll(!showAll)}
                    style={{ background: "transparent", border: "1px solid rgba(0,0,0,0.15)", padding: "10px 32px", color: "rgba(0,0,0,0.4)", fontFamily: "'Oswald', sans-serif", fontSize: "0.75rem", letterSpacing: "0.15em", cursor: "pointer", transition: "border-color 0.15s, color 0.15s" }}
                    onMouseEnter={(e) => { e.currentTarget.style.borderColor = RED; e.currentTarget.style.color = RED; }}
                    onMouseLeave={(e) => { e.currentTarget.style.borderColor = "rgba(0,0,0,0.15)"; e.currentTarget.style.color = "rgba(0,0,0,0.4)"; }}
                  >
                    {showAll ? "SHOW LESS" : `LOAD MORE — ${filtered.length - 9} MORE`}
                  </button>
                </div>
              )}
            </>
          )}
        </div>
      </main>

      {/* Footer */}
      <footer style={{ borderTop: "1px solid rgba(0,0,0,0.08)", background: "#ede9e3", position: "relative", zIndex: 10 }}>
        <div style={{ height: "2px", background: RED }} />
        <div style={{ maxWidth: "1280px", margin: "0 auto", padding: "8px 32px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <span style={{ fontFamily: "monospace", fontSize: "0.58rem", letterSpacing: "0.14em", color: "rgba(0,0,0,0.35)" }}>
            © 2026 STEM COMMONS. ALL RIGHTS RESERVED.
          </span>
          <div style={{ display: "flex", gap: "24px" }}>
            {["ABOUT", "CONTACT", "PRIVACY"].map((link) => (
              <button key={link}
                style={{ fontFamily: "monospace", fontSize: "0.58rem", letterSpacing: "0.14em", color: "rgba(0,0,0,0.35)", background: "none", border: "none", cursor: "pointer", transition: "color 0.15s", padding: 0 }}
                onMouseEnter={(e) => (e.currentTarget.style.color = RED)}
                onMouseLeave={(e) => (e.currentTarget.style.color = "rgba(0,0,0,0.35)")}
              >{link}</button>
            ))}
          </div>
        </div>
      </footer>
    </div>
  );
}

/* ─── SHARED COMPONENTS ──────────────────────────────────────── */

const navBtnStyle: React.CSSProperties = {
  fontFamily: "'Oswald', sans-serif",
  fontSize: "0.78rem",
  letterSpacing: "0.15em",
  color: "rgba(0,0,0,0.45)",
  background: "none",
  border: "none",
  cursor: "pointer",
  padding: 0,
  transition: "color 0.15s",
};

function SidebarSection({
  title, items, selected, onToggle, checkbox = false,
}: {
  title: string; items: string[]; selected: string[]; onToggle: (v: string) => void; checkbox?: boolean;
}) {
  return (
    <div style={{ marginBottom: "22px" }}>
      <div style={{ fontFamily: "'Oswald', sans-serif", fontSize: "0.78rem", fontWeight: 600, letterSpacing: "0.15em", color: RED, marginBottom: "8px" }}>
        {title}
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: "1px" }}>
        {items.map((item) => {
          const active = selected.includes(item);
          return (
            <button
              key={item}
              onClick={() => onToggle(item)}
              style={{
                display: "flex", alignItems: "center", gap: "9px", textAlign: "left", width: "100%",
                padding: "6px 9px", background: active ? "rgba(196,26,10,0.07)" : "transparent",
                border: "none", borderLeft: active ? `2px solid ${RED}` : "2px solid transparent",
                cursor: "pointer", transition: "background 0.1s",
              }}
            >
              {checkbox && (
                <span style={{ width: "12px", height: "12px", border: `1px solid ${active ? RED : "rgba(0,0,0,0.2)"}`, display: "inline-flex", alignItems: "center", justifyContent: "center", flexShrink: 0, background: active ? RED : "transparent", color: "#fff", fontSize: "8px" }}>
                  {active ? "✓" : ""}
                </span>
              )}
              <span style={{ fontFamily: "'Barlow', sans-serif", fontSize: "0.82rem", color: active ? "#1a1a1a" : "rgba(0,0,0,0.5)" }}>
                {item}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

function ActionBtn({ children, filled = false }: { children: React.ReactNode; filled?: boolean }) {
  return (
    <button
      style={{ background: filled ? RED : "transparent", border: `1px solid ${RED}`, padding: "10px 0", color: filled ? "#fff" : RED, fontFamily: "'Oswald', sans-serif", fontSize: "0.72rem", letterSpacing: "0.15em", cursor: "pointer", width: "100%", transition: "opacity 0.15s, background 0.15s" }}
      onMouseEnter={(e) => { if (filled) e.currentTarget.style.opacity = "0.85"; else e.currentTarget.style.background = "rgba(196,26,10,0.08)"; }}
      onMouseLeave={(e) => { if (filled) e.currentTarget.style.opacity = "1"; else e.currentTarget.style.background = "transparent"; }}
    >
      {children}
    </button>
  );
}

function ResourceCard({ resource }: { resource: (typeof resources)[number] }) {
  const typeColor = typeColors[resource.type] || "#888";
  const statusSty = statusStyles[resource.status] || { color: "#888", bg: "transparent", border: "transparent" };

  return (
    <div
      style={{ background: "#fff", border: "1px solid rgba(0,0,0,0.1)", display: "flex", flexDirection: "column", cursor: "pointer", transition: "border-color 0.2s, background 0.2s" }}
      onMouseEnter={(e) => { (e.currentTarget as HTMLDivElement).style.borderColor = "rgba(196,26,10,0.35)"; (e.currentTarget as HTMLDivElement).style.background = "#fdf8f6"; }}
      onMouseLeave={(e) => { (e.currentTarget as HTMLDivElement).style.borderColor = "rgba(0,0,0,0.1)"; (e.currentTarget as HTMLDivElement).style.background = "#fff"; }}
    >
      <div style={{ height: "2px", background: typeColor }} />
      <div style={{ padding: "14px", display: "flex", flexDirection: "column", gap: "10px", flex: 1 }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <span style={{ fontFamily: "monospace", fontSize: "0.55rem", letterSpacing: "0.18em", color: typeColor, background: `${typeColor}15`, border: `1px solid ${typeColor}30`, padding: "2px 7px" }}>
            {resource.type.toUpperCase()}
          </span>
          <span style={{ fontFamily: "monospace", fontSize: "0.52rem", letterSpacing: "0.1em", color: statusSty.color, background: statusSty.bg, border: `1px solid ${statusSty.border}`, padding: "2px 7px" }}>
            {resource.status.toUpperCase()}
          </span>
        </div>
        <div style={{ fontFamily: "'Oswald', sans-serif", fontSize: "0.95rem", fontWeight: 600, letterSpacing: "0.03em", color: "#1a1a1a", lineHeight: 1.3 }}>
          {resource.name}
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: "5px" }}>
          <MapPin size={10} style={{ color: "rgba(0,0,0,0.3)", flexShrink: 0 }} />
          <span style={{ fontFamily: "'Barlow', sans-serif", fontSize: "0.78rem", color: "rgba(0,0,0,0.48)" }}>
            {resource.city}, {resource.state}
          </span>
        </div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: "5px", marginTop: "auto" }}>
          {resource.facilities.map((f) => (
            <span key={f} style={{ fontFamily: "monospace", fontSize: "0.5rem", letterSpacing: "0.1em", color: "rgba(0,0,0,0.38)", border: "1px solid rgba(0,0,0,0.1)", padding: "2px 5px" }}>
              {f.toUpperCase()}
            </span>
          ))}
        </div>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", paddingTop: "10px", borderTop: "1px solid rgba(0,0,0,0.07)" }}>
          <span style={{ fontFamily: "monospace", fontSize: "0.56rem", color: "rgba(0,0,0,0.32)", letterSpacing: "0.03em" }}>
            {resource.contact}
          </span>
          <ExternalLink size={11} style={{ color: RED, opacity: 0.65 }} />
        </div>
      </div>
    </div>
  );
}
