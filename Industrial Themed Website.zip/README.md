
  # Industrial Themed Website

  This is a code bundle for Industrial Themed Website. The original project is available at https://www.figma.com/design/SwkilqFrnystfNLXptanVi/Industrial-Themed-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  